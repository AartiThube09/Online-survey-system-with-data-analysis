import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the data from the Excel file
file_path = 'C:\\Users\\dell5\\OneDrive\\Desktop\\online survey system\\online_data\\Amazon_Products.xlsx'
df = pd.read_excel(file_path)

# Print the number of entities in the dataset
print(f"Number of products in the dataset: {len(df)}")
print("Products available in the dataset:")
print(df[['Product_Name', 'Product_Price', 'Product_Reviews']])  # Display relevant columns

# Clean the data 
df = df[df['Product_Name'] != '']

# Check if there are any entries to visualize
if df.empty:
    print("No data available for visualization.")
else:
    # Convert Product_Price to numeric 
    df['Product_Price'] = df['Product_Price'].replace({'\$': '', ',': ''}, regex=True).astype(float)

    # Clean and convert Product_Reviews to numeric
    df['Product_Reviews'] = df['Product_Reviews'].str.replace(' ratings', '').str.replace(',', '').astype(float)

    # Select the top 10 products by number of reviews
    top_products = df.nlargest(10, 'Product_Reviews')
    
    
    # Visualize the distribution of product prices
    plt.figure(figsize=(10, 6))
    sns.histplot(df['Product_Price'], bins=30, kde=True)
    plt.title('Distribution of Product Prices')
    plt.xlabel('Price ($)')
    plt.ylabel('Frequency')
    plt.grid()
    plt.show()  

    # Visualize the number of reviews
    plt.figure(figsize=(10, 6))
    top_reviews = df.nlargest(10, 'Product_Reviews')  
    sns.barplot(x='Product_Name', y='Product_Reviews', data=top_reviews)
    plt.title('Top 10 Products by Number of Reviews')
    plt.xticks(rotation=45, ha='right')
    plt.ylabel('Number of Reviews')
    plt.xlabel('Product Name')
    plt.tight_layout()
    plt.show()  
    
    

    # Visualize the proportion of reviews using a pie chart
    plt.figure(figsize=(8, 8))
    plt.pie(top_reviews['Product_Reviews'],
            labels=top_reviews['Product_Name'],
            autopct='%1.1f%%',
            startangle=140,
            labeldistance=1.3,  
            wedgeprops=dict(edgecolor='w'))  
    plt.title('Top 10 Products by Review Proportion')
   
    plt.axis('equal')  
    plt.show()  
